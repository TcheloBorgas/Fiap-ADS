public interface Imprimir {
    void exibirDados();
}